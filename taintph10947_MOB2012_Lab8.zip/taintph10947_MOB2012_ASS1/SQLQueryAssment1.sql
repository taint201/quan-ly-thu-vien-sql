﻿create database QuanLySach
if OBJECT_ID ('phanloai') is not null
drop table phanloai
go
create table phanloai(
	maphanloai varchar(10) primary key,
	tenphanloai nvarchar(50),
)
--end table phan loai
if OBJECT_ID ('NXB') is not null
drop table NXB
go
create table NXB(
	maNXB varchar(10) primary key,
	tenNXB nvarchar(255),
	diachi nvarchar(50)
)
--end table NXB
if OBJECT_ID ('tacgia') is not null
drop table tacgia
go
create table tacgia(
	matacgia varchar(10) primary key,
	hoten nvarchar(255),
	ngaysinh date,
	gioitinh nvarchar(20)
)
--end table tac gia
if OBJECT_ID ('nganh') is not null
drop table nganh
go
create table nganh(
	manganh varchar(10) primary key,
	tennganh nvarchar(255),
)
--end table nghanh
if OBJECT_ID ('lop') is not null
drop table lop
go
create table lop(
	malop varchar(10) primary key,
	masv varchar(10),
	manganh varchar(10),
	foreign key (manganh) references nganh(manganh)
)
--end tablelop
if OBJECT_ID ('sinhvien') is not null
drop table sinhvien
go
create table sinhvien(
	masinhvien varchar(10) primary key,
	hoten nvarchar(255),
	ngaysinh date,
	gioitinh nvarchar(20),
	ngaysinhratruong date,
	malop varchar(10)
	foreign key (malop) references lop(malop),
)
--end table lop
if OBJECT_ID ('sinhvienlop') is not null
drop table sinhvienlop
go
create table sinhvienlop(
    malop varchar(10)  ,
	masinhvien varchar(10) ,
	primary key(malop,masinhvien),
	foreign key (malop) references lop(malop),
	foreign key (masinhvien) references sinhvien(masinhvien),
)
--end table sinh vien lop
if OBJECT_ID ('sach') is not null
drop table sach
go
create table sach(
    masach varchar(10)  primary key,
	tieude nvarchar(50),
	sotrang int check(sotrang>5),
	soluongbansao int check(soluongbansao>1),
	giatien money check(giatien>0),
	vitri nvarchar(50),
	ngaynhap date,
	maphanloai varchar (10),
	matacgia varchar(10),
	maNXB varchar(10),
	foreign key (matacgia ) references tacgia(matacgia),
	foreign key (maphanloai ) references phanloai(maphanloai),
	foreign key (maNXB) references NXB(maNXB)
)
--end table sach
if OBJECT_ID ('phieumuon') is not null
drop table phieumuon
go
create table phieumuon(
    sophieu int identity(1,1) primary key,
	masinhvien varchar(10),
	ngaymuon date,
	ngaytra date,
	trangthai int check(trangthai=1 or trangthai=0),--1 la da tra, 0 laf chua tra
	foreign key (masinhvien) references sinhvien(masinhvien)
)
--end table phieu muon
if OBJECT_ID ('chitietphieu') is not null
drop table chitietphieu
go
create table chitietphieu(
    masach varchar(10),
	sophieu int not null,
	ghichu nvarchar(50),
	primary key(sophieu,masach),
	foreign key (masach) references sach(masach),
	foreign key (sophieu) references phieumuon(sophieu),
)
--end table chi tiet phieu muon
select*from phanloai --in ra bang phan loai
select*from NXB --in ra bang NXB
select*from tacgia --in ra bang phan loai
select*from nganh --in ra bang nganh
select*from lop --in ra bang lop
select*from sinhvien --in ra bang sinh vien
select*from sinhvienlop --in ra bang sinh vien lop
select*from sach --in ra bang sach
select*from phieumuon --in ra bang phieu muon
select*from phanloai --in ra bang chit iet phieu

delete from phanloai --xóa dữ liệu bảng
insert into phanloai(maphanloai,tenphanloai) values
	('MKTSALE', N'Maketting sale'),
	('TKDH', N'Photopshop cơ bản'),
	('LTWEB', N'Lập trình Web'),
	('LTMOBILE', N'Lập trình Mobile' ),
	('LTIOT', N'Lập trình IOT' )

delete from NXB --xóa dữ liệu bảng	
insert into NXB(maNXB,tenNXB,diachi) values 
    ('NXB1',N' Ngô Tài',N'Đại Mỗ - Nam Từ Liêm -Hà Nội'),
	('NXB2',N' Ngô Văn Chung',N'Khương Đình - Thanh Xuân - Hà Nội'),
	('NXB3',N' Ngô Văn Dũng',N'Nhật Tân -Hà Nội'),
	('NXB4',N' Ngô Ngọc Hải',N'Cầu Giấy -Hà Nội'),
	('NXB5',N' Ngô Văn Quang',N'Thanh Trì-Hà Nội'),
	('NXB6',N' Ngô Văn Tiến',N'Hiệp Hòa - Bắc Giang'),
	('NXB7',N' Ngô Văn Thịnh',N'Đại Mỗ - Nam Từ Liêm -Hà Nội'),
	('NXB8',N' Ngô Phương Oanh',N'Hiệp Hòa - Bắc Giang'),
	('NXB9',N' Nguyễn Thị dung',N'Hiệp Hòa - Bắc Giang'),
	('NXB10',N' Nguyễn Xuân Kiên',N'Cầu Giấy -Hà Nội')


	